<nav class="site-navigation position-relative text-right" role="navigation">
              <ul class="site-menu main-menu js-clone-nav mr-auto d-none d-lg-block">
              <li><a class="nav-link">Todos</a></li>
              <li><a href="../../index.php" class="nav-link">Liga</a></li>
                <li><a href="partidos.php" class="nav-link">Partidos</a></li>
                <li><a href="jugadores.php" class="nav-link">Jugadores</a></li>
                <li><a href="equipos.php" class="nav-link">Equipos</a></li>
                <li><a href="altasbajas.php" class="nav-link">Altas y Bajas</a></li>
                <li><a href="../../php/inicio/index.html" class="nav-link">Cuenta</a></li>
              </ul>
            </nav>